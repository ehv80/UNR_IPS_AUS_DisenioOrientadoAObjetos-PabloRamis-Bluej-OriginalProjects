/**
 * A class that models an auction bid.
 * It contains a reference to the bidder and the amount bid.
 * ----------------------------------------------------------------------------
 * Una clase que modela una oferta de una subasta. Contiene una referencia a
 * un objeto de la clase Person denominado "bidder" que representa al oferente
 * y una referencia al monto de la oferta.
 * ----------------------------------------------------------------------------
 * @author David J. Barnes and Michael Kolling.
 * @version 2001.08.26
 */
public class Bid
{
    // The user making the bid. El oferente.
    private final Person bidder;
    // The value of the bid. This could be a large number so
    // the long type has been used.
    // El valor de la oferta. Como puede ser un valor muy grande se usa un 
    //"long"
    private final long value;

    /**
     * Create a bid.
     * ----------------------------------------------------------------------------
     * Constructor de esta clase Bid que toma como par�metros la referencia a un 
     * objeto de la clase Person denominado "bidder" y un entero largo que 
     * representa el valor de la oferta "value".
     * ----------------------------------------------------------------------------
     * @param bidder Who is bidding for the lot.
     * @param value The value of the bid.
     */
    public Bid(Person bidder, long value)
    {
        this.bidder = bidder;
        this.value = value;
    }

    /**
     * @return The bidder.
     * ----------------------------------------------------------------------------
     * M�todo que retorna un objeto de la clase Person denominado "bidder" que 
     * representa al oferente.
     * ----------------------------------------------------------------------------
     */
    public Person getBidder()
    {
        return bidder;
    }

    /**
     * @return The value of the bid.
     * ----------------------------------------------------------------------------
     * M�todo que retorna un entero largo denominado "value" que representa el 
     * valor de la oferta.
     * ----------------------------------------------------------------------------
     */
    public long getValue()
    {
        return value;
    }
}
