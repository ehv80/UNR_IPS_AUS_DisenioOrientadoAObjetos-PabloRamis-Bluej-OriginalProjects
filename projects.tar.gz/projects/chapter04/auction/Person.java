/**
 * Maintain details of someone who participates in an auction.
 * ----------------------------------------------------------------------------
 * Mantiene los detalles de alguien que participa en una subasta.
 * ----------------------------------------------------------------------------
 * @author David J. Barnes and Michael Kolling.
 * @version 2001.05.31
 */
public class Person
{
    // The name of this user. El nombre de este usuario.
    private final String name;

    /**
     * Create a new user with the given name.
     * ----------------------------------------------------------------------------
     * Constructor de esta clase Person que toma como par�metro una cadena de 
     * caracteres que representa el nombre de esa persona.
     * ----------------------------------------------------------------------------
     * @param name The user's name.
     */
    public Person(String name)
    {
        this.name = name;
    }

    /**
     * @return The user's name.
     * ----------------------------------------------------------------------------
     * M�todo que retorna la cadena de caracteres que representa al nombre de la 
     * persona.
     * ----------------------------------------------------------------------------
     */
    public String getName()
    {
        return name;
    }
}
