/**
 * A class to model an item (or set of items) in an
 * auction: a lot.
 * ----------------------------------------------------------------------------
 * Una clase para modelar un elemento (o un conjunto de elementos) en una 
 * subasta: un lote.
 * ----------------------------------------------------------------------------
 * @author David J. Barnes and Michael Kolling.
 * @version 2003.10.06
 */
public class Lot
{
    // A unique identifying number.
    private final int number;
    // A description of the lot.
    private String description;
    // The current highest bid for this lot.
    private Bid highestBid;

    /**
     * Construct a Lot, setting its number and description.
     * ------------------------------------------------------------------------
     * Constructor de esta clase Lot que toma como par�metros un entero 
     * "number" y una cadena de caracteres "description" necesarias para la
     * instanciaci�n de un objeto de esta clase Lot.
     * ------------------------------------------------------------------------
     * @param number The lot number.
     * @param description A description of this lot.
     */
    public Lot(int number, String description)
    {
        this.number = number;
        this.description = description;
    }

    /**
     * Attempt to bid for this lot. A successful bid
     * must have a value higher than any existing bid.
     * ------------------------------------------------------------------------
     * Intento de una oferta para este lote. Una oferta satisfactoria debe 
     * tener un valor m�s alto que el de cualquier oferta existente.
     * Este m�todo retorna un valor booleano.
     * En el caso que el Bid "highestBid", que representa la oferta con valor 
     * m�s alto, es "null", o bi�n si el valor de la oferta que se est� 
     * haciendo es mayor que el valor de la oferta m�s alta existente hasta 
     * ahora, entonces la oferta que se est� haciendo pasa a ser la oferta con 
     * valor m�s alto y retorna "true". De lo contrario retorna "false".
     * ------------------------------------------------------------------------
     * @param bid A new bid.
     * @return true if successful, false otherwise
     */
    public boolean bidFor(Bid bid)
    {
        if((highestBid == null) ||
               (bid.getValue() > highestBid.getValue())) {
            // This bid is the best so far.
            highestBid = bid;
            return true;
        }
        else {
            return false;
        }
    }
    
    /**
     * @return A string representation of this lot's details.
     * ------------------------------------------------------------------------
     * Retorna una cadena de caracteres denominada "details" que posee los 
     * detalles de ese lote.
     * ------------------------------------------------------------------------
     */
    public String toString()
    {
        String details = number + ": " + description;
        if(highestBid != null) {
            details += "    Bid: " + 
                       highestBid.getValue();
        }
        else {
            details += "    (No bid)";
        }
        return details;
    }

    /**
     * @return The lot's number.
     * -------------------------------------------------------------------------
     * Retorna el n�mero de ese lote.
     * -------------------------------------------------------------------------
     */
    public int getNumber()
    {
        return number;
    }

    /**
     * @return The lot's description.
     * -------------------------------------------------------------------------
     * Retorna la cadena de caracteres "description" de ese lote.
     * -------------------------------------------------------------------------
     */
    public String getDescription()
    {
        return description;
    }

    /**
     * @return The highest bid for this lot. This could be null if
     *         there are no current bids.
     *--------------------------------------------------------------------------
     *Retorna la oferta con valor m�s alto para ese lote. Este m�todo deber�a 
     *retornar "null" si el lote no teine ofertas actualmente.
     *--------------------------------------------------------------------------
     */
    public Bid getHighestBid()
    {
        return highestBid;
    }
}
